import {Route, BrowserRouter, Routes} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./Pages/Home";
import AllProducts from "./Pages/AllProducts";
import SpecificProduct from "./Pages/SpecificProduct";

function App() {
  return (
   <div>
    <BrowserRouter>
      <Routes>
      {/* Normal Routing */}
        <Route path="/" element={<Home/>}/>
        <Route path="/home" element={<Home/>}/>
        <Route path="/products" element={<AllProducts/>}/>
        <Route path="/specific products" element={<SpecificProduct/>}/>

      {/* Nested Routing */}
        {/* <Route path="/" element={<Home/>}>
          <Route path="home/" element={<Home/>}>
            <Route path="products" element={<AllProducts/>}/>
            <Route path="specific products" element={<SpecificProduct/>}/> 
          </Route>
        </Route> */}
      </Routes>
    </BrowserRouter>
   </div>
  );
}

export default App;
