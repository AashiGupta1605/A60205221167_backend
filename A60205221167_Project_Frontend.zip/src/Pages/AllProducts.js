import React from 'react'
import Header from '../Components/Header'
import FetchData from '../Components/FetchData'
const AllProducts = () => {
  return (
    <div>
      <Header/>
      <FetchData/>
    </div>
  )
}

export default AllProducts