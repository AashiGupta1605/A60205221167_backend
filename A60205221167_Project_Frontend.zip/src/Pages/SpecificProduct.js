import React from 'react'
import Header from '../Components/Header'

const SpecificProduct = () => {
  return (
    <div>
      <Header/>
    </div>
  )
}

export default SpecificProduct