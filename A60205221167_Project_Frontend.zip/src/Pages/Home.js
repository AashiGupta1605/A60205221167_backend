import React from 'react';
import Header from '../Components/Header';

//React Arrow function component default export

const Home = () => { 
  return (
    <div>
      <Header/>
    </div>
  )
}

export default Home 