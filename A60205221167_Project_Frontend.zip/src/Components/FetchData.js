import React from 'react'
import { useState, useEffect } from 'react';

const FetchData = () => {
  // const [product, setProduct] = useState([]);
  const product = async() => {
    const data = await fetch('http://20.244.56.144/test/companies/AMZ/categories/Laptop/products?top-10@minPrice=1&maxPrice=1 0000')
    console.log(data)
  };
    useEffect(() => {
        product();
      }, []);

  return (
    <>
    <table border={1} aria-setsize={80}>
    <caption><font color="orange" size="6"><u>PRODUCTS</u></font></caption>
    {product.map((product) => (
      <>
        <tr>
          <td>
            {product.productName}
          </td>
          <td>{product.price}</td>
          <td>{product.rating}</td>
          <td>{product.discount}</td>
          <td>{product.availability}</td>
        </tr>
      </>
    ))}  
    </table>
    </>
  )
}

export default FetchData